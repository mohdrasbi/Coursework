/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_166()
{
    return 3347663086U;
}

unsigned addval_498(unsigned x)
{
    return x + 3281017004U;
}

unsigned getval_117()
{
    return 2496104776U;
}

void setval_320(unsigned *p)
{
    *p = 3347662938U;
}

unsigned getval_458()
{
    return 2553594696U;
}

void setval_260(unsigned *p)
{
    *p = 2455254123U;
}

unsigned addval_149(unsigned x)
{
    return x + 3284638024U;
}

unsigned getval_489()
{
    return 2425393240U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_307(unsigned *p)
{
    *p = 3281047944U;
}

unsigned getval_304()
{
    return 2496563642U;
}

unsigned addval_259(unsigned x)
{
    return x + 3525889673U;
}

unsigned getval_440()
{
    return 3224421001U;
}

unsigned getval_287()
{
    return 3677409673U;
}

void setval_272(unsigned *p)
{
    *p = 2447411528U;
}

unsigned addval_136(unsigned x)
{
    return x + 3269495112U;
}

void setval_452(unsigned *p)
{
    *p = 3221802633U;
}

void setval_169(unsigned *p)
{
    *p = 3281178249U;
}

unsigned addval_224(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_202(unsigned x)
{
    return x + 3682910857U;
}

unsigned getval_372()
{
    return 3526935241U;
}

void setval_182(unsigned *p)
{
    *p = 3677933961U;
}

void setval_399(unsigned *p)
{
    *p = 3251734888U;
}

unsigned getval_445()
{
    return 2425406089U;
}

unsigned getval_315()
{
    return 3286272344U;
}

void setval_361(unsigned *p)
{
    *p = 3374370441U;
}

void setval_106(unsigned *p)
{
    *p = 2463205724U;
}

void setval_381(unsigned *p)
{
    *p = 3221278345U;
}

void setval_150(unsigned *p)
{
    *p = 3285096955U;
}

unsigned addval_370(unsigned x)
{
    return x + 3221799625U;
}

void setval_319(unsigned *p)
{
    *p = 3281044169U;
}

unsigned addval_486(unsigned x)
{
    return x + 3286272328U;
}

void setval_210(unsigned *p)
{
    *p = 3515428374U;
}

void setval_159(unsigned *p)
{
    *p = 2425409921U;
}

void setval_456(unsigned *p)
{
    *p = 2445445479U;
}

unsigned getval_438()
{
    return 2464188744U;
}

unsigned addval_120(unsigned x)
{
    return x + 2430635336U;
}

void setval_355(unsigned *p)
{
    *p = 3524841097U;
}

unsigned addval_223(unsigned x)
{
    return x + 3767076951U;
}

unsigned addval_248(unsigned x)
{
    return x + 1774371465U;
}

unsigned addval_226(unsigned x)
{
    return x + 3229143433U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
